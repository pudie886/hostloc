<?php
return array (
  'accounts' =>
  array (
    0 =>
    array (
      'username' => 'user1',
      'password' => 'pass1',
      'last_brush' => '',
    ),
    1 =>
    array (
      'username' => 'user2',
      'password' => 'pass2',
      'last_brush' => '',
    ),
  ),
  'tg_push_key' => '',
);